package com.example.lc.snakegame;

import android.graphics.Canvas;
import android.provider.Settings;
import android.view.SurfaceHolder;

/**
 * Created by Leonardo on 25-06-2017.
 */

public class LoopThread extends Thread{

    private boolean running;
    private SurfaceHolder surfaceHolder;
    private GameSurfaceView gameSurfaceView;
    private double max_fps;
    private Canvas canvas;


   public LoopThread(SurfaceHolder surfaceHolder,GameSurfaceView gameSurfaceView){
       running=false;
       max_fps=30;
       this.surfaceHolder=surfaceHolder;
       this.gameSurfaceView=gameSurfaceView;
   }

   public void setRunning(boolean running){
       this.running=running;
   }

    @Override
    public void run() {
        long startTime;
        long frameDurationMillis;
        long targetTime=(long)(1000/max_fps);
        long waitTime;
        long totalTime=0;
        int frameCounter=0;
        double averageFps;


        while(running){
            startTime= System.nanoTime();
            canvas=null;

                try {
                    canvas = surfaceHolder.lockCanvas();

                    synchronized (surfaceHolder) {
                        gameSurfaceView.update();
                        gameSurfaceView.draw(canvas);
                    }
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                finally {
                    if (canvas != null) {
                        try {
                            surfaceHolder.unlockCanvasAndPost(canvas);
                        }
                        catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                }

            frameDurationMillis=(System.nanoTime()-startTime)/1000000;
            waitTime=targetTime-frameDurationMillis;

            try{
                if(waitTime>0){
                    this.sleep(waitTime);
                }
            }catch(Exception e){ e.printStackTrace();}

            totalTime=totalTime+(System.nanoTime()-startTime);
            frameCounter++;

            if(frameCounter==10){
                averageFps=((double)frameCounter*1000)/((double)totalTime/1000000);
                frameCounter=0;
                totalTime=0;
                ///uncomment to print the average fps
                 //System.out.println(averageFps);
            }


            /*if(gameSurfaceView.game.getPlaying()==false && gameSurfaceView.startedGame==true){
                running=false;
                gameSurfaceView.lossScreen();
            }*/



        }


    }

}
