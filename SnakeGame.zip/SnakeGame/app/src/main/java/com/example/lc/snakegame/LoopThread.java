package com.example.lc.snakegame;

import android.content.Context;
import android.graphics.Canvas;
import android.provider.Settings;
import android.view.SurfaceHolder;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

/**
 * Created by Leonardo on 25-06-2017.
 */

public class LoopThread extends Thread{

    private boolean running;
    private SurfaceHolder surfaceHolder;
    private GameSurfaceView gameSurfaceView;
    private double max_fps;
    private Canvas canvas;
    private Context context;
    private FileInputStream fileInputStream;
    private InputStream inputStream;
    private boolean useDefaultFile;


   public LoopThread(SurfaceHolder surfaceHolder,GameSurfaceView gameSurfaceView,Context context){
       running=false;
       this.surfaceHolder=surfaceHolder;
       this.gameSurfaceView=gameSurfaceView;
       this.context=context;
       readSettings();
   }

    public void readSettings(){
        boolean exists;
        File file= context.getFileStreamPath("settings");
        fileInputStream=null;
        inputStream=null;

        if(file==null || !file.exists()){
            exists=false;
        }
        else{
            exists=true;
        }


        if(exists){
            try {
                fileInputStream = context.openFileInput("settings");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        else{
            try {
                inputStream =context.getAssets().open("settings.txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

        if(fileInputStream==null && inputStream!=null){
            useDefaultFile=true;
        }
        else if(fileInputStream!=null && inputStream==null){
            useDefaultFile=false;
        }
        else{
            useDefaultFile=true;
        }

        readFPS();
    }

    public void readFPS(){
        String message="";
        boolean reading;
        int character;

        if(useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = inputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
        else if(!useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }

        max_fps=2 + 58*(Double.parseDouble(message)/100);

        try {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        try {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

   public void setRunning(boolean running){
       this.running=running;
   }

    @Override
    public void run() {
        long startTime;
        long frameDurationMillis;
        long targetTime=(long)(1000/max_fps);
        long waitTime;
        long totalTime=0;
        int frameCounter=0;
        double averageFps;


        while(running){
            startTime= System.nanoTime();
            canvas=null;

                try {
                    canvas = surfaceHolder.lockCanvas();

                    synchronized (surfaceHolder) {
                        gameSurfaceView.update();
                        gameSurfaceView.draw(canvas);
                    }
                }
                catch(Exception e){
                    e.printStackTrace();
                }
                finally {
                    if (canvas != null) {
                        try {
                            surfaceHolder.unlockCanvasAndPost(canvas);
                        }
                        catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                }

            frameDurationMillis=(System.nanoTime()-startTime)/1000000;
            waitTime=targetTime-frameDurationMillis;

            try{
                if(waitTime>0){
                    this.sleep(waitTime);
                }
            }catch(Exception e){ e.printStackTrace();}

            totalTime=totalTime+(System.nanoTime()-startTime);
            frameCounter++;

            if(frameCounter==10){
                averageFps=((double)frameCounter*1000)/((double)totalTime/1000000);
                frameCounter=0;
                totalTime=0;
                ///uncomment to print the average fps
                 //System.out.println(averageFps);
            }


            if(gameSurfaceView.game.playing==false && gameSurfaceView.game.startedGame==true){
                running=false;
                gameSurfaceView.lossScreen();
            }

        }

    }

}
