package com.example.lc.snakegame;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Random;

/**
 * Created by Leonardo on 25-06-2017.
 */

public class Game {

    public double[][] snake;
    public int[] corners;
    public int[] direction;
    public double[] food;
    public int leftOver_x;
    public int leftOver_y;
    public int squareSize;
    public double incrementAmount;
    public double currentIncrement;
    public boolean playing;
    public boolean startedGame;
    public int nextDirection;
    public int snakeSize;
    public int sizeX;
    public int sizeY;
    public int numberOfSquaresX;
    public int numberOfSquaresY;
    public boolean dontIncrementlastOne;
    public boolean wallTeleport;

    public Game(int width,int height,Context context){

        playing=false;
        startedGame=false;

        double ratio= (double)100/1440;
        squareSize= (int)(width*ratio);

        while(squareSize % 3 != 0){
            squareSize++;
        }

        numberOfSquaresX=width/squareSize;
        numberOfSquaresY=height/squareSize;

        sizeX=numberOfSquaresX*squareSize;
        sizeY=numberOfSquaresY*squareSize;

        leftOver_x=width-sizeX;
        leftOver_y=height-sizeY;

        snake=new double[numberOfSquaresX*numberOfSquaresY][2];
        direction=new int[numberOfSquaresX*numberOfSquaresY];

        for(int i=0;i<numberOfSquaresX*numberOfSquaresY;i++){
            snake[i][0]=-1;
            snake[i][1]=-1;

            direction[i]=-1;
        }

        incrementAmount=(double)squareSize/3;

        currentIncrement=0;

        snake[0][0]=3*squareSize;
        snake[0][1]=3*squareSize;

        direction[0]=3;
        nextDirection=3;

        snakeSize=1;

        corners=null;

        food=new double[2];
        foodPos();

        dontIncrementlastOne=false;

        readTeleport(context);
    }

    public void readTeleport(Context context){
        boolean exists;
        File file= context.getFileStreamPath("settings");
        FileInputStream fileInputStream=null;
        InputStream inputStream=null;
        String message="";
        boolean reading;
        boolean useDefaultFile;
        int character;
        boolean canRead=false;

        if(file==null || !file.exists()){
            exists=false;
        }
        else{
            exists=true;
        }


        if(exists){
            try {
                fileInputStream = context.openFileInput("settings");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        else{
            try {
                inputStream =context.getAssets().open("settings.txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

        if(fileInputStream==null && inputStream!=null){
            useDefaultFile=true;
        }
        else if(fileInputStream!=null && inputStream==null){
            useDefaultFile=false;
        }
        else{
            useDefaultFile=true;
        }


        if(useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = inputStream.read();
                    if (((char)character)!='/' && canRead){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        if(!canRead){
                            canRead=true;
                        }else {
                            reading = false;
                        }
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
        else if(!useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char)character)!='/' &&  canRead){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        if(!canRead){
                            canRead=true;
                        }else {
                            reading = false;
                        }
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }


        if(Integer.parseInt(message)==0){
            wallTeleport=false;
        }
        else if(Integer.parseInt(message)==1){
            wallTeleport=true;
        }



        try {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        try {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void update(){
        if(playing) {
            if (currentIncrement == (double) squareSize) {
                updateSnakePos();
                updateDirections();
                updateCorners();
                checkFoodCatch();
                currentIncrement=0;
            }
            currentIncrement=currentIncrement+incrementAmount;
            lossCheck();

            if(playing==false){
                currentIncrement=currentIncrement-incrementAmount;

            }
        }
    }


    public void updateSnakePos(){
        for(int i=snakeSize-1; i>=0;i--){
            if(i!=0) {
                snake[i][0] = snake[i - 1][0];
                snake[i][1] = snake[i - 1][1];
            }
            else if(i==0){
                double x=0;
                double y=0;

                switch(direction[0]){
                    case 0:
                        x=snake[0][0]-squareSize;
                        y=snake[0][1];
                        break;
                    case 1:
                        x=snake[0][0];
                        y=snake[0][1]-squareSize;
                        break;
                    case 2:
                        x=snake[0][0]+squareSize;
                        y=snake[0][1];
                        break;
                    case 3:
                        x=snake[0][0];
                        y=snake[0][1]+squareSize;
                        break;
                }

                if(wallTeleport==true){
                    if(x<0){
                        x=squareSize*(numberOfSquaresX-1);
                    }
                    else if(y<0){
                        y=squareSize*(numberOfSquaresY-1);
                    }
                    else if(x > squareSize*(numberOfSquaresX-1)){
                        x=0;
                    }
                    else if(y > squareSize*(numberOfSquaresY-1)){
                        y=0;
                    }
                }
                    snake[0][0] = x;
                    snake[0][1] = y;

            }
        }
    }

    public void updateDirections() {
        for (int i = snakeSize - 1; i >= 0; i--) {
            if (i != 0) {
                direction[i] = direction[i - 1];
            } else if (i == 0) {
                     if(!((direction[0]==0 && nextDirection==2)||
                        (direction[0]==1 && nextDirection==3)||
                        (direction[0]==2 && nextDirection==0)||
                        (direction[0]==3 && nextDirection==1))){

                    direction[0]=nextDirection;
                }
            }
        }
    }

    public void updateCorners(){
        int counter=0;

        for (int i = snakeSize - 1; i > 0; i--) {
            if(direction[i]!=direction[i-1]){
                counter=counter+1;
            }
        }

        if(counter>0) {
            corners = new int[counter];
            int currentPos=corners.length-1;

            for (int i = snakeSize - 1; i > 0; i--) {
                if(direction[i]!=direction[i-1]){
                    corners[currentPos]=i-1;
                    currentPos--;
                }
            }
        }
        else{
            corners=null;
        }
    }

    public void lossCheck(){
        double x=0;
        double y=0;

        switch(direction[0]){
            case 0:
                x=snake[0][0]-currentIncrement;
                y=snake[0][1];
                break;
            case 1:
                x=snake[0][0];
                y=snake[0][1]-currentIncrement;
                break;
            case 2:
                x=snake[0][0]+currentIncrement;
                y=snake[0][1];
                break;
            case 3:
                x=snake[0][0];
                y=snake[0][1]+currentIncrement;
                break;
        }

        if(wallTeleport==false) {
            if (x < 0 || x > (sizeX - squareSize) || y < 0 || y > (sizeY - squareSize)) {
                playing = false;
            }
        }

        for(int i=1;i<snakeSize;i++){
            if(snake[0][0]==snake[i][0] && snake[0][1]==snake[i][1] && snakeSize != 2){
                playing=false;
            }
        }

        if(snakeSize==numberOfSquaresX*numberOfSquaresY){
            playing=false;
        }

    }


    public void foodPos(){
        boolean confirmed=false;

        Random random=new Random();
        double x;
        double y;

        while(!confirmed){
            x=random.nextInt(numberOfSquaresX);
            y=random.nextInt(numberOfSquaresY);

            food[0]=x*squareSize;
            food[1]=y*squareSize;

            confirmed=true;

            for(int i =0;i<snakeSize;i++){
                if(snake[i][0]== food[0] && snake[i][1]== food[1]){
                    confirmed=false;
                }
            }
        }
    }

    public void checkFoodCatch(){
        if(snake[0][0]==food[0] && snake[0][1]==food[1]){
            foodPos();
            snakeSize++;
            dontIncrementlastOne=true;
            snake[snakeSize-1][0]=snake[snakeSize-2][0];
            snake[snakeSize-1][1]=snake[snakeSize-2][1];
            direction[snakeSize-1]=direction[snakeSize-2];
        }
        else{
            dontIncrementlastOne=false;
        }
    }
}
