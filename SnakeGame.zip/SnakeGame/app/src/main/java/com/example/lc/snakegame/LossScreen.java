package com.example.lc.snakegame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class LossScreen extends AppCompatActivity {

    public Intent menuIntent;
    public Intent retryIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_loss_screen);

        TextView bestScore =(TextView)findViewById(R.id.textView4);
        TextView score =(TextView)findViewById(R.id.textView5);

        int score_value =(int)getIntent().getExtras().get("Score");

        String scoreMessage="Score: "+score_value;
        score.setText(scoreMessage.toCharArray(),0,scoreMessage.toCharArray().length);

        int bestScore_value=readBestScoreFile();

        String bestScoreMessage="Best Score: "+bestScore_value;
        bestScore.setText(bestScoreMessage.toCharArray(),0,bestScoreMessage.toCharArray().length);

        if(score_value>bestScore_value){
            saveBestScore(score_value);
        }

        Button mainMenu=(Button)findViewById(R.id.menu);
        Button retry=(Button)findViewById(R.id.retry);

        menuIntent=new Intent(this,MainMenu.class);
        retryIntent=new Intent(this,GameActivity.class);

        mainMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(menuIntent);
            }
        });

       retry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(retryIntent);
            }
        });
    }

    public void saveBestScore(int score_value){
        FileOutputStream fileOutputStream=null;
        String message="";

        message=score_value+"/";

        try {
            fileOutputStream = openFileOutput("bestscore", MODE_PRIVATE);
            fileOutputStream.write(message.getBytes());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }

    public int readBestScoreFile(){
        int value=0;
        boolean exists;
        File file= getFileStreamPath("bestscore");
        FileInputStream fileInputStream=null;
        String message="";
        boolean reading;
        int character;

        if(file==null || !file.exists()){
            exists=false;
        }
        else{
            exists=true;
        }

        if(exists){
            try {
                fileInputStream = openFileInput("bestscore");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        else{
            value=0;
        }

        if(fileInputStream!=null) {
            try {
                reading = true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char) character) != '/') {
                        message = message + (char) character;
                    } else if (((char) character) == '/') {
                        reading = false;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


            value=Integer.parseInt(message);
        }


        try {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        return value;
    }
}
