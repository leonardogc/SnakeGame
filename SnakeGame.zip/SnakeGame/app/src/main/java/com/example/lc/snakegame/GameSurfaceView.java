package com.example.lc.snakegame;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;

/**
 * Created by Leonardo on 25-06-2017.
 */

public class GameSurfaceView extends SurfaceView implements SurfaceHolder.Callback{

    public int width;
    public int height;
    public LoopThread loopThread;
    public int touch_x;
    public int touch_y;
    public int touch_distance;
    public Game game;
    public Context context;


    public GameSurfaceView(Context context){
        super(context);
        getHolder().addCallback(this);
        setFocusable(true);

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        width = size.x;
        height = size.y;

        double touch_ratio=(double)100/1440;

        touch_distance=(int)(touch_ratio*width);


        game=new Game(width,height,context);
        this.context=context;

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        loopThread=new LoopThread(getHolder(),this,context);
        loopThread.setRunning(true);
        loopThread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry=true;
        while(retry){
            retry=false;
            try {
                loopThread.setRunning(false);
                loopThread.join();
            }catch (Exception e){
                e.getStackTrace();
                retry=true;
            }
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int option;
        int dx=0;
        int dy=0;
        int distance=0;


        if(event.getAction()!= MotionEvent.ACTION_DOWN){
            dx=(int)event.getX()-touch_x;
            dy=(int)event.getY()-touch_y;
            distance=(int)Math.sqrt(dx*dx+dy*dy);
        }

        if(event.getAction()== MotionEvent.ACTION_DOWN){
            touch_x=(int)event.getX();
            touch_y=(int)event.getY();
        }
        else if(distance > touch_distance){
            if(Math.abs(dx) > Math.abs(dy)){
                if(dx<0){
                    option=0;
                }
                else{
                    option=2;
                }
            }
            else{
                if(dy<0){
                    option=1;
                }
                else {
                    option=3;
                }
            }

            game.nextDirection=option;

            if(!game.playing){
                game.direction[0]=option;
                game.playing=true;
                game.startedGame=true;
            }

                touch_x=(int)event.getX();
                touch_y=(int)event.getY();

        }

        return true;
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);

        int grid_thickness=1;

        Paint grid=new Paint();
        grid.setColor(Color.BLACK);

        Paint food=new Paint();
        food.setColor(Color.RED);

        Paint snakeColor=new Paint();
        snakeColor.setColor(Color.GRAY);

        Paint background=new Paint();
        background.setColor(Color.rgb(255,255,255));

        //draw background
        canvas.drawColor(background.getColor());

        // draw grid
        for(int i=game.leftOver_x/2; i<width;i=i+game.squareSize) {
            canvas.drawRect(new Rect(i, game.leftOver_y/2, i+grid_thickness, height-game.leftOver_y/2), grid);
        }

        for(int i=game.leftOver_y/2; i<height;i=i+game.squareSize) {
            canvas.drawRect(new Rect(game.leftOver_x/2, i, width-game.leftOver_x/2,i+grid_thickness),grid);
        }

        //draw food
        canvas.drawRect(new Rect((int) game.food[0] + game.leftOver_x / 2,
                (int) game.food[1] + game.leftOver_y / 2,
                (int) game.food[0] + game.squareSize + grid_thickness + game.leftOver_x / 2,
                (int) game.food[1] + game.squareSize + grid_thickness + game.leftOver_y / 2), food);


        //draw snake
        if(game.corners!=null){
            for (int i=0;i<game.corners.length;i++){
                canvas.drawRect(new Rect((int) game.snake[game.corners[i]][0] + game.leftOver_x / 2,
                        (int) game.snake[game.corners[i]][1] + game.leftOver_y / 2,
                        (int) game.snake[game.corners[i]][0] + grid_thickness + game.squareSize + game.leftOver_x / 2,
                        (int) game.snake[game.corners[i]][1] + grid_thickness + game.squareSize + game.leftOver_y / 2), snakeColor);
            }
        }


        for(int i=game.snakeSize-1;i>=0;i--) {

            if (i == 0) {
               snakeColor.setColor(Color.DKGRAY);
            }

            double x = 0;
            double y = 0;

            if (game.dontIncrementlastOne && i == game.snakeSize - 1) {
                canvas.drawRect(new Rect((int) game.snake[i][0] + game.leftOver_x / 2,
                        (int) game.snake[i][1] + game.leftOver_y / 2,
                        (int) game.snake[i][0] + grid_thickness + game.squareSize + game.leftOver_x / 2,
                        (int) game.snake[i][1] + grid_thickness + game.squareSize + game.leftOver_y / 2), snakeColor);

            } else {

                switch (game.direction[i]) {
                    case 0:
                        x = game.snake[i][0] - game.currentIncrement;
                        y = game.snake[i][1];
                        break;
                    case 1:
                        x = game.snake[i][0];
                        y = game.snake[i][1] - game.currentIncrement;
                        break;
                    case 2:
                        x = game.snake[i][0] + game.currentIncrement;
                        y = game.snake[i][1];
                        break;
                    case 3:
                        x = game.snake[i][0];
                        y = game.snake[i][1] + game.currentIncrement;
                        break;
                }

                if(game.wallTeleport==true){
                    if(x<0){
                        canvas.drawRect(new Rect((int) (game.sizeX-game.currentIncrement + game.leftOver_x / 2),
                                (int) y + game.leftOver_y / 2,
                                (int)(game.sizeX-game.currentIncrement + grid_thickness + game.leftOver_x / 2 + game.squareSize),
                                (int) y + game.squareSize + grid_thickness + game.leftOver_y / 2), snakeColor);
                    }
                    else if(y<0){
                        canvas.drawRect(new Rect((int) x + game.leftOver_x / 2,
                                (int) (game.sizeY-game.currentIncrement + game.leftOver_y / 2),
                                (int) x + game.squareSize + grid_thickness + game.leftOver_x / 2,
                                (int) (game.sizeY-game.currentIncrement + grid_thickness + game.leftOver_y / 2 + game.squareSize)), snakeColor);
                    }
                    else if(x > game.squareSize*(game.numberOfSquaresX-1)){
                        canvas.drawRect(new Rect((int) (game.currentIncrement-game.squareSize+game.leftOver_x / 2),
                                (int) y + game.leftOver_y / 2,
                                (int)(game.currentIncrement+ grid_thickness+game.leftOver_x / 2),
                                (int) y + game.squareSize +grid_thickness+ game.leftOver_y / 2), snakeColor);
                    }
                    else if(y > game.squareSize*(game.numberOfSquaresY-1)){
                        canvas.drawRect(new Rect((int) x + game.leftOver_x / 2,
                                (int)(game.currentIncrement-game.squareSize+game.leftOver_y / 2),
                                (int) x + game.squareSize+grid_thickness + game.leftOver_x / 2,
                                (int) (game.currentIncrement+grid_thickness+game.leftOver_y / 2)), snakeColor);
                    }
                }

                canvas.drawRect(new Rect((int) x + game.leftOver_x / 2,
                        (int) y + game.leftOver_y / 2,
                        (int) x + game.squareSize+grid_thickness + game.leftOver_x / 2,
                        (int) y + game.squareSize+grid_thickness + game.leftOver_y / 2), snakeColor);
            }
        }

        //clear edges
        canvas.drawRect(new Rect(0,0,game.leftOver_x/2,height),background);
        canvas.drawRect(new Rect(0,0,width,game.leftOver_y/2),background);
        canvas.drawRect(new Rect(game.leftOver_x/2+game.sizeX + grid_thickness,0,width,height),background);
        canvas.drawRect(new Rect(0,game.leftOver_y/2+game.sizeY+grid_thickness,width,height),background);
    }


    public void update(){
       game.update();
    }

    public void lossScreen(){
        Intent lossScreen= new Intent(context,LossScreen.class);
        lossScreen.putExtra("Score",game.snakeSize);
        context.startActivity(lossScreen);
    }
}
