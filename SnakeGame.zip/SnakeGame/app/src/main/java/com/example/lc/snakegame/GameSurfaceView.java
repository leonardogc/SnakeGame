package com.example.lc.snakegame;

import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;

/**
 * Created by Leonardo on 25-06-2017.
 */

public class GameSurfaceView extends SurfaceView implements SurfaceHolder.Callback{

    public int width;
    public int height;
    public LoopThread loopThread;
    public int touch_x;
    public int touch_y;
    public Game game;
    public Context context;


    public GameSurfaceView(Context context){
        super(context);
        getHolder().addCallback(this);
        setFocusable(true);

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        width = size.x;
        height = size.y;

        game=new Game(width,height);
        this.context=context;

    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        loopThread=new LoopThread(getHolder(),this,context);
        loopThread.setRunning(true);
        loopThread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry=true;
        while(retry){
            retry=false;
            try {
                loopThread.setRunning(false);
                loopThread.join();
            }catch (Exception e){
                e.getStackTrace();
                retry=true;
            }
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int option;

        if(event.getAction() == MotionEvent.ACTION_DOWN){
            touch_x=(int)event.getX();
            touch_y=(int)event.getY();
        }
        else if(event.getAction() == MotionEvent.ACTION_UP){
            int delta_x=(int)event.getX()-touch_x;
            int delta_y=(int)event.getY()-touch_y;

            if(Math.abs(delta_x)  > Math.abs(delta_y)){
                if(delta_x<0){
                    option=0;
                }
                else{
                    option=2;
                }
            }
            else{
                if(delta_y<0){
                    option=1;
                }
                else {
                    option=3;
                }
            }

            game.nextDirection=option;

            if(!game.playing){
                game.direction[0]=option;
                game.playing=true;
                game.startedGame=true;
            }
        }
        return true;
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        canvas.drawColor(Color.rgb(255,255,255));

        Paint grid=new Paint();
        grid.setColor(Color.BLACK);

        Paint food=new Paint();
        food.setColor(Color.RED);

        Paint snakeColor=new Paint();
        snakeColor.setColor(Color.GRAY);


        for(int i=game.leftOver_x/2; i<=width-game.leftOver_x/2;i=i+game.squareSize) {
            canvas.drawRect(new Rect(i, game.leftOver_y/2, i+1, height-game.leftOver_y/2), grid);
        }

        for(int i=game.leftOver_y/2; i<=height-game.leftOver_y/2;i=i+game.squareSize) {
            canvas.drawRect(new Rect(game.leftOver_x/2, i, width-game.leftOver_x/2,i+1),grid);
        }

        canvas.drawRect(new Rect((int) game.food[0] + game.leftOver_x / 2,
                (int) game.food[1] + game.leftOver_y / 2,
                (int) game.food[0] + game.squareSize + game.leftOver_x / 2,
                (int) game.food[1] + game.squareSize + game.leftOver_y / 2), food);


        if(game.corners!=null){
            for (int i=0;i<game.corners.length;i++){
                canvas.drawRect(new Rect((int) game.snake[game.corners[i]][0] + game.leftOver_x / 2,
                        (int) game.snake[game.corners[i]][1] + game.leftOver_y / 2,
                        (int) game.snake[game.corners[i]][0] + game.squareSize + game.leftOver_x / 2,
                        (int) game.snake[game.corners[i]][1] + game.squareSize + game.leftOver_y / 2), snakeColor);
            }
        }


        for(int i=game.snakeSize-1;i>=0;i--) {

            if (i == 0) {
                snakeColor.setColor(Color.DKGRAY);
            }

            double x = 0;
            double y = 0;

            if (game.dontIncrementlastOne && i == game.snakeSize - 1) {
                canvas.drawRect(new Rect((int) game.snake[i][0] + game.leftOver_x / 2,
                        (int) game.snake[i][1] + game.leftOver_y / 2,
                        (int) game.snake[i][0] + game.squareSize + game.leftOver_x / 2,
                        (int) game.snake[i][1] + game.squareSize + game.leftOver_y / 2), snakeColor);

            } else {

                switch (game.direction[i]) {
                    case 0:
                        x = game.snake[i][0] - game.currentIncrement;
                        y = game.snake[i][1];
                        break;
                    case 1:
                        x = game.snake[i][0];
                        y = game.snake[i][1] - game.currentIncrement;
                        break;
                    case 2:
                        x = game.snake[i][0] + game.currentIncrement;
                        y = game.snake[i][1];
                        break;
                    case 3:
                        x = game.snake[i][0];
                        y = game.snake[i][1] + game.currentIncrement;
                        break;
                }
                canvas.drawRect(new Rect((int) x + game.leftOver_x / 2,
                        (int) y + game.leftOver_y / 2,
                        (int) x + game.squareSize + game.leftOver_x / 2,
                        (int) y + game.squareSize + game.leftOver_y / 2), snakeColor);
            }
        }

    }


    public void update(){
       game.update();
    }

    public void lossScreen(){
        Intent lossScreen= new Intent(context,MainMenu.class);
        context.startActivity(lossScreen);
    }
}
