package com.example.lc.snakegame;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.WindowManager;

/**
 * Created by Leonardo on 25-06-2017.
 */

public class GameSurfaceView extends SurfaceView implements SurfaceHolder.Callback{

    public int width;
    public int height;
    public LoopThread loopThread;
    public double x;
    public double y;
    public boolean moving;
    public int direction;
    public int previousDirection;
    public int square;

    public int touch_x;
    public int touch_y;


    public GameSurfaceView(Context context){
        super(context);
        getHolder().addCallback(this);
        setFocusable(true);

        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        width = size.x;
        height = size.y;

        x=0;
        y=0;
        moving=false;
        direction = 2;
        square=100;

        System.out.println("Array Size = "+ (width/square)*(height/square));
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        loopThread=new LoopThread(getHolder(),this);
        loopThread.setRunning(true);
        loopThread.start();
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        boolean retry=true;
        while(retry){
            retry=false;
            try {
                loopThread.setRunning(false);
                loopThread.join();
            }catch (Exception e){
                e.getStackTrace();
                retry=true;
            }
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(!moving){
            moving=true;
        }

        if(event.getAction() == MotionEvent.ACTION_DOWN){
            touch_x=(int)event.getX();
            touch_y=(int)event.getY();
        }
        else if(event.getAction() == MotionEvent.ACTION_UP){
            int delta_x=(int)event.getX()-touch_x;
            int delta_y=(int)event.getY()-touch_y;

            if(Math.abs(delta_x)  > Math.abs(delta_y)){
                if(delta_x<0){
                    previousDirection=direction;
                    direction=0;
                }
                else if(delta_x>0){
                    previousDirection=direction;
                    direction=2;
                }
            }
            else{
                if(delta_y<0){
                    previousDirection=direction;
                    direction=1;
                }
                else if(delta_y>0){
                    previousDirection=direction;
                    direction=3;
                }
            }
        }
        return true;
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        canvas.drawColor(Color.rgb(255,255,255));

        Paint blue=new Paint();
        blue.setColor(Color.BLUE);

        Paint black=new Paint();
        black.setColor(Color.BLACK);

        int size_x=square*(width/square);
        int size_y=square*(height/square);

        int leftOver_x=width-size_x;
        int leftOver_y=height-size_y;


        for(int i=leftOver_x/2; i<=width-leftOver_x/2;i=i+square) {
            canvas.drawRect(new Rect(i - 1, leftOver_y/2, i, height-leftOver_y/2), blue);
        }

        for(int i=leftOver_y/2; i<=height-leftOver_y/2;i=i+square) {
            canvas.drawRect(new Rect(leftOver_x/2, i-1, width-leftOver_x/2,i),blue);
        }

        canvas.drawRect(new Rect((int)x+leftOver_x/2, (int)y+leftOver_y/2, (int)x+square+leftOver_x/2, (int)y+square+leftOver_y/2), black);

    }


    public void update(){
        double speed=(double)square/10;

        if(moving){
         switch(direction){
             case 0:
                 if(y%(double)square==0) {
                     x=x-speed;
                 }
                 else{
                     if(previousDirection==1){
                         y=y-speed;
                     }
                     else if(previousDirection==3){
                         y=y+speed;
                     }
                 }
                 break;
             case 1:
                 if(x%(double)square==0) {
                     y=y-speed;
                 }
                 else{

                 if(previousDirection==0){
                     x=x-speed;
                 }
                 else if(previousDirection==2){
                     x=x+speed;
                 }
             }
                 break;
             case 2:
                 if(y%(double)square==0) {
                     x=x+speed;
                 }else{
                     if(previousDirection==1){
                         y=y-speed;
                     }
                     else if(previousDirection==3){
                         y=y+speed;
                     }
                 }

                 break;
             case 3:
                 if(x%(double)square==0) {
                     y=y+speed;
                 }
                 else{

                    if(previousDirection==0){
                        x=x-speed;
                    }
                    else if(previousDirection==2){
                        x=x+speed;
                        }
                 }
                 break;
            }
        }
    }
}
