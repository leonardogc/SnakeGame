package com.example.lc.snakegame;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

public class SettingsActivity extends AppCompatActivity {

    public Intent startBack;
    public SeekBar seekBar;
    public Switch simpleSwitch;
    public TextView bestScore;
    private FileInputStream fileInputStream;
    private InputStream inputStream;
    private boolean useDefaultFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_settings);

        Button back =(Button)findViewById(R.id.back);
        seekBar =(SeekBar)findViewById(R.id.seekBar);
        simpleSwitch=(Switch)findViewById(R.id.switch1);
        bestScore=(TextView)findViewById(R.id.textView6);


        startBack=new Intent(this,MainMenu.class);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSettings();
                startActivity(startBack);
            }
        });

        readSettings();
        readBestScore();
    }

    public void readSettings(){
        boolean exists;
        File file= getFileStreamPath("settings");
        fileInputStream=null;
        inputStream=null;

        if(file==null || !file.exists()){
            exists=false;
        }
        else{
            exists=true;
        }



        if(exists){
            try {
                fileInputStream = openFileInput("settings");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        else{
            try {
                inputStream =getAssets().open("settings.txt");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }

        if(fileInputStream==null && inputStream!=null){
            useDefaultFile=true;
        }
        else if(fileInputStream!=null && inputStream==null){
            useDefaultFile=false;
        }
        else{
            useDefaultFile=true;
        }

        readSeekBar();
        readSwitch();
    }

    public void readSeekBar(){
        String message="";
        boolean reading;
        int character;

        if(useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = inputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
        else if(!useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }

        seekBar.setProgress(Integer.parseInt(message));

    }

    public void readSwitch(){
        String message="";
        boolean reading;
        int character;

        if(useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = inputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }

        }
        else if(!useDefaultFile){
            try {
                reading=true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char)character)!='/'){
                        message=message+(char)character;
                    }else if(((char)character)=='/'){
                        reading=false;
                    }
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }


        if(Integer.parseInt(message)==0){
            simpleSwitch.setChecked(false);
        }
        else if(Integer.parseInt(message)==1){
            simpleSwitch.setChecked(true);
        }



        try {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }

        try {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void readBestScore(){
        int value=0;
        boolean exists;
        File file= getFileStreamPath("bestscore");
        FileInputStream fileInputStream=null;
        String message="";
        boolean reading;
        int character;

        if(file==null || !file.exists()){
            exists=false;
        }
        else{
            exists=true;
        }

        if(exists){
            try {
                fileInputStream = openFileInput("bestscore");
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        else{
            value=0;
        }

        if(fileInputStream!=null) {
            try {
                reading = true;
                while (reading) {
                    character = fileInputStream.read();
                    if (((char) character) != '/') {
                        message = message + (char) character;
                    } else if (((char) character) == '/') {
                        reading = false;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }


            value=Integer.parseInt(message);
        }


        try {
            if (fileInputStream != null) {
                fileInputStream.close();
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }


        String bestScoreMessage="Best Score: "+value;
        bestScore.setText(bestScoreMessage.toCharArray(),0,bestScoreMessage.toCharArray().length);
    }

    public void saveSettings(){
        FileOutputStream fileOutputStream=null;
        String message="";

        message=seekBar.getProgress()+"/";

        if(simpleSwitch.isChecked()){
            message=message+1+"/";
        }
        else if(!simpleSwitch.isChecked()){
            message=message+0+"/";
        }

        try {
            fileOutputStream = openFileOutput("settings", MODE_PRIVATE);
            fileOutputStream.write(message.getBytes());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            try {
                if (fileOutputStream != null) {
                    fileOutputStream.close();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
    }
}
